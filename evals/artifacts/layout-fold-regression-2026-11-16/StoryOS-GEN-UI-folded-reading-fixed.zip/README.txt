GEN-UI Folded Reading Fix · Offline StoryOS Preview

Report HTML is a byte-identical copy of the 2026-11-14 native Codex model output.
Only three local CSS resources were updated: document.css, heading-nav.css, typography.css.
This is an adapted delivery preview, NOT a new model generation or a business implementation verification.
The separate screenshots with synthetic quotation text are regression fixtures and are not included here.
Open report.html in a desktop Chrome/Edge browser; no network required.
